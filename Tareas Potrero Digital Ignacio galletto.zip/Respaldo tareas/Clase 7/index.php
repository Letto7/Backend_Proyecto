<?php
function calcularCuadrado($lado) {
    $perimetro = 4 * $lado;
    $superficie = $lado * $lado;
    echo "El perímetro del cuadrado es: " . $perimetro . "<br>";
    echo "La superficie del cuadrado es: " . $superficie;
}
$lado = 5;
calcularCuadrado($lado);

echo "<br><br>";

function mostrarEnMayusculas($cadena) {
$mayusculas = strtoupper($cadena);   
echo "La cadena en mayúsculas es: " . $mayusculas . "<br>";
}


$cadena = "Hola Mundo";
mostrarEnMayusculas($cadena);


function mostrarEnMinusculas($cadena) {
$minusculas = strtolower($cadena);
echo "La cadena en minúsculas es: " . $minusculas;
}

$cadena = "Hola Mundo";
mostrarEnMinusculas($cadena);
echo "<br><br>";

function diasDelMes($mes) {
    if ($mes == 4 || $mes == 6 || $mes == 9 || $mes == 11) {
        return "El mes tiene 30 días.";
    } elseif ($mes == 2) {
        return "El mes tiene 28 o 29 días (dependiendo si es año bisiesto).";
    } else {
        return "El mes tiene 31 días.";
    }
}

$mes = 2;  
$resultado = diasDelMes($mes);

echo $resultado;
?>
