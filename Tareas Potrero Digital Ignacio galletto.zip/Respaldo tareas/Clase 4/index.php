<?php

$n = 10; 

if ($n > 0) {
    echo "El número ingresado es un número positivo";
}

echo "<br>";
$n = 5; 

if ($n > 1 && $n < 10) {
    echo "El número ingresado es mayor a 1 y menor a 10";
}
echo "<br>";

$n = 15; 

if ($n >= 10 || $n < 2) {
    echo "El número ingresado es mayor o igual a 10 o menor a 2";
} else {
    echo "El número ingresado no pudo ser validado";
}
    echo "<br>";


$numero1 = 8; 
$numero2 = 5; 


if ($numero1 > $numero2) {
    echo "Suma: " . ($numero1 + $numero2) . "<br>";
    echo "Resta: " . ($numero1 - $numero2) . "<br>";
}

if ($numero2 > $numero1) {
    echo "Multiplicación: " . ($numero1 * $numero2) . "<br>";
    echo "División entera: " . ($numero1 / $numero2) . "<br>";
    echo "Resto: " . ($numero1 % $numero2) . "<br>";
}

if ($numero1 == $numero2) {
    echo "Los números ingresados son iguales";
}
?>