<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de la Calificación</title>
</head>
<body>
    <?php
    if (isset($_GET['nombre']) && isset($_GET['nota'])) {
        $nombre = $_GET['nombre'];
        $nota = $_GET['nota'];
        $calificacion = "";

        if ($nota >= 0 && $nota <= 2) {
            $calificacion = "Muy deficiente";
        } elseif ($nota >= 3 && $nota <= 5) {
            $calificacion = "Insuficiente";
        } elseif ($nota >= 6 && $nota <= 7) {
            $calificacion = "Bien";
        } elseif ($nota >= 8 && $nota <= 9) {
            $calificacion = "Notable";
        } elseif ($nota == 10) {
            $calificacion = "Sobresaliente";
        } else {
            $calificacion = "Nota no válida";
        }

        echo "<h3>Resultado:</h3>";
        echo "<p>Alumno: $nombre</p>";
        echo "<p>Calificación: $calificacion</p>";
    } else {
        echo "<p>Por favor, ingrese el nombre y la nota del alumno desde el formulario.</p>";
    }

        if (!isset($_GET['nombre']) || $_GET['nombre'] == "") {
            echo "<p>Error: El nombre del alumno no fue ingresado.</p>";
        } elseif (!isset($_GET['nota']) || $_GET['nota'] == "") {
            echo "<p>Error: La nota no fue ingresada.</p>";
        } else {
            $nombre = $_GET['nombre'];
            $nota = $_GET['nota'];
    
            if (!is_numeric($nota)) {
                echo "<p>Error: La nota debe ser un número.</p>";
            } elseif ($nota < 0 || $nota > 10) {
                echo "<p>Error: La nota debe estar entre 0 y 10.</p>";
            } else {
                $calificacion = "";
                if ($nota >= 0 && $nota <= 2) {
                    $calificacion = "Muy deficiente";
                } elseif ($nota >= 3 && $nota <= 5) {
                    $calificacion = "Insuficiente";
                } elseif ($nota >= 6 && $nota <= 7) {
                    $calificacion = "Bien";
                } elseif ($nota >= 8 && $nota <= 9) {
                    $calificacion = "Notable";
                } elseif ($nota == 10) {
                    $calificacion = "Sobresaliente";
                }
    
                echo "<h3>Resultado:</h3>";
                echo "<p>Alumno: $nombre</p>";
                echo "<p>Calificación: $calificacion</p>";
            }
        }
        ?>
</body>
</html>