<?php
$i = 1;
while ($i <= 9) {
    echo $i . "<br>";
    $i++;
}
echo "<br>";

$i = 9;
while ($i >= 1) {
    echo $i . "<br>";
    $i--;
}
echo "<br>";

$i = 2; 
while ($i <= 20) {
    echo $i . "<br>";
    $i += 2; 
}
echo "<br>";



$i = 1; 
while ($i <= 20) {
    echo $i . "<br>";
    $i += 2; 
}
echo "<br>";

$i = 1;
$suma = 0;
while ($i <= 20) {
    $suma += $i; 
    $i++;
}
echo "La suma de los números del 1 al 20 es: " . $suma;
echo "<br>";


$i = 2; 
$suma = 0;
while ($i <= 20) {
    $suma += $i; 
    $i += 2; 
}
echo "La suma de los números pares del 1 al 20 es: " . $suma;
echo "<br>";
?>