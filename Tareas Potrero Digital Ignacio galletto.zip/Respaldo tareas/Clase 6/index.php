<?php

$numerosPares = array();

for ($i = 1; $i <= 10; $i++ ) {
    $numerosPares []=$i * 2;
}

foreach ($numerosPares as $numero) {
    echo $numero . "<br>";
}
echo "<br><br>";

$persona =array(
"Nombre" => "Pedro",
"Apellido"=> "Torres",
"Dirección"=> "Av. Mayo 3703",
"Teléfono"=> "1122334455"
);
foreach ($persona as $clave => $valor ) {
    echo $clave. ":" . $valor . "<br>";
}

echo "<br><br>";

$ciudades = array("Madrid", "Barcelona", "Londres", "New York", "Los Ángeles", "Chicago");

foreach ($ciudades as $indice => $ciudad){
    echo "La ciudad con el indice $indice tiene el nombre de $ciudad.<br>";
}
echo "<br><br>";

$ciudades = array(
    "MD" => "Madrid",
    "BCL" => "Barcelona",
    "LD" => "Londres",
    "NY" => "New York",
    "LA" => "Los Ángeles",
    "CCG" => "Chicago"
);

foreach($ciudades as $indice => $ciudad){
    echo "El indice de $ciudad es $indice.<br>";
}
?>