<?php 
    echo "Hola Mundo";
    $variable = "Hola Mundo"; 
    echo "<br>";
    echo $variable;

    $numero1 ="15"; 
    $numero2 ="5";

    echo "<br>";
    echo $numero1 + $numero2;

    echo "<br>";
    echo $numero1 - $numero2;
    echo "<br>";
    echo $numero1 * $numero2;
    echo "<br>";
    echo $numero1 / $numero2;
    echo "<br>";
    echo $numero1 % $numero2;
    echo "<br>";

    $celsius = 20; 
    $fahrenheit = $celsius * (9 / 5) + 32; 

    echo "$celsius °C es igual a $fahrenheit °F"; 

    echo "<br>";
    $base = 18; 
    $altura = 12; 

    $perimetro = 2 * ($base + $altura);

    $area = $base * $altura;

    echo "<br>";
    echo "El perímetro del rectángulo es: $perimetro cm\n";
    echo "<br>";
    echo "El área del rectángulo es: $area cm²";
?>