<?php 
$conexion = mysqli_connect("127.0.0.1:3306", "root", "", "proyecto_backend1");

$query = "SELECT * FROM productos";
$resultado = mysqli_query($conexion, $query);

echo '<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestión de Productos</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <h2>Gestión de Productos</h2>';

echo "<a href='./formulario_agregar_producto.php'>AGREGAR PRODUCTO</a>";
echo '<table>
    <thead>
      <tr>
        <th>Producto</th>
        <th>Precio</th>
        <th>Cantidad en Stock</th>
        <th>Marca</th>
        <th>‎ </th>
      </tr>
    </thead>
    <tbody>'; 
while ($unaFila = mysqli_fetch_assoc($resultado)) {
    $idProducto = $unaFila['id_producto']; 
    $precio = $unaFila['precio_producto'];
    $stock = $unaFila['stock_producto'];
    $marca = $unaFila['marca_producto'];

    echo '<tr>
        <td>
          <div class="imagen_producto">
            <img src="' . $unaFila["imagen_producto"] . '" alt="Imagen del producto">
            <div>
              <p>' . $unaFila['nombre_producto'] . '</p>
            </div>
          </div>
        </td>
        <td>$' . $precio . '</td>
        <td><p>' . $stock . '</p></td>
        <td>' . $marca . '</td>
        <td>
        <a href="eliminar_producto.php?id=' . $idProducto . '">Eliminar</a>
        </td>
      </tr>';
}

echo '</tbody>
  </table>
</body>
</html>';

mysqli_close($conexion);
?>
