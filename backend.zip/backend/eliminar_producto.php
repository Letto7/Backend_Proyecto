<?php

if (isset($_GET['id'])) {
    $id_producto = $_GET['id'];  

    $conexion = mysqli_connect("127.0.0.1:3306", "root", "", "proyecto_backend1");

    if ($conexion) {

        $query = "DELETE FROM productos WHERE id_producto = $id_producto";


        $resultado = mysqli_query($conexion, $query);


        if ($resultado) {
            header("Location: index.php");  
            exit; 
        } else {
            echo "Hubo un error al eliminar el producto.";
        }


        mysqli_close($conexion);
    } else {
        echo "Error de conexión a la base de datos.";
    }
} else {
    echo "No se recibió el ID del producto.";
}
?>
