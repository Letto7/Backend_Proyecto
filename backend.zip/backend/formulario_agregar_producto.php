<link rel="stylesheet" href="Mis_estilos.css">

<form action="./agregar_producto.php" method="post" enctype="multipart/form-data">
    <label>Nombre:</label>
    <input type="text" id="nombre_producto" name="nombre_producto" autocomplete="off">
    <br>
    <label>Marca:</label>
    <input type="text" id="marca_producto" name="marca_producto" autocomplete="off">
    <br>
    <label>Precio:</label>
    <input type="number" id="precio_producto" name="precio_producto" step="0.001" min="0" autocomplete="off">
    <br>
    <label>Stock:</label>
    <input type="number" id="stock_producto" name="stock_producto" min="0" autocomplete="off">
    <br>
    <label>Imagen:</label>
    <input type="file" id="imagen_producto" name="imagen_producto">
    <br>
    <button type="submit">Agregar</button>
    <a href="./productos.php">Volver</a>
</form>
