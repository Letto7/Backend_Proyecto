<?php 

$nombre_producto = $_POST["nombre_producto"];
$marca_producto = $_POST["marca_producto"];
$precio_producto = $_POST["precio_producto"];
$stock_producto = $_POST["stock_producto"];

$imagen_producto = $_FILES["imagen_producto"];

$type = pathinfo($imagen_producto["name"], PATHINFO_EXTENSION);

$data = file_get_contents($imagen_producto["tmp_name"]);

$imagen_base64 = "data:image/" . $type . ";base64," . base64_encode($data);

$conexion = mysqli_connect("127.0.0.1:3306", "root", "", "proyecto_backend1");

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$query = "INSERT INTO productos (nombre_producto, marca_producto, precio_producto, stock_producto, imagen_producto) 
          VALUES ('" . $nombre_producto . "', '" . $marca_producto . "', '" . $precio_producto . "', '" . $stock_producto . "', '" . $imagen_base64 . "')";

$resultado = mysqli_query($conexion, $query);

if ($resultado) {

    header('Location: index.php');
} else {

    echo "Error en la consulta: " . mysqli_error($conexion);
}


mysqli_close($conexion);

?>
